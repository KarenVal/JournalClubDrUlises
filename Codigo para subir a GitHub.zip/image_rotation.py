import numpy as np
import cv2

# Load an Image and set grayscale
img = cv2.imread('orapple.jpg', 0)
# Get the number of pixels in width and height and set the value to rows and cols vars
rows, cols = img.shape

# Apply 90 degrees rotation
M = cv2.getRotationMatrix2D((cols/2, rows/2), 90, 1)
dst = cv2.warpAffine(img, M, (cols, rows))

# Create a window to show the image loaded
cv2.imshow('Image', dst)

cv2.waitKey(0)
cv2.destroyAllWindow()