import argparse
import cv2

# This code allows you to load an image on disc and select a region of interest
# by drawing a square using the mouse
# After drawing the square, you need to click key 'C' to crop the image and show it
# in a new Window

refPt = []
cropping = False

# This function is responsible for setting rectangle origin and size by capturing mouse
# coordinates when pressing and releasing mouse left button
def drag_and_crop(event, x, y, flags, param):

	global refPt, cropping
	
	# Set rectangle origin when On Press button is detected
	if event == cv2.EVENT_LBUTTONDOWN:
		refPt = [(x, y)]
		cropping = True
	# Set rectangle width & hight when On Release button is detected
	elif event == cv2.EVENT_LBUTTONUP:
		refPt.append((x, y))
		cropping = False
	
	# Set values to a rectangle
	cv2.rectangle(image, refPt[0], refPt[1], (0, 255, 0), 2)
	#Draw rectangle
	cv2.imshow("Image", image)

# Open and show the image
image = cv2.imread('orapple.jpg')
clone = image.copy()
cv2.namedWindow("Image")
# Add a mouse listener to the Image window
cv2.setMouseCallback("Image", drag_and_crop)

while True:
	cv2.imshow("Image", image)
	key = cv2.waitKey(1) & 0xFF

	if key == ord("c"):
		break

if len(refPt) == 2:
	roi = clone[refPt[0][1]:refPt[1][1], refPt[0][0]:refPt[1][0]]
	cv2.imshow("ROI", roi)
	cv2.waitKey(0)

cv2.destroyAllWindow()
