import numpy as np
import cv2

# Open a video file in the same folder
cap = cv2.VideoCapture('video.avi')

# Read all the frames
while(cap.isOpened()):
    ret, frame = cap.read()
	
	# OPTIONAL: you can set this attribute to see the video in gray scale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    cv2.imshow('frame',gray)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()