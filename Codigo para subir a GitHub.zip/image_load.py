import numpy as np
import cv2

# This code allows you to load an image on disc, displaying it in a window

# Load an Image and set grayscale
img = cv2.imread('background.png', 0)

# Create a window to show the image loaded
cv2.imshow('Image', img)

# Wait for a key to be pressed
cv2.waitKey(0)
cv2.destroyAllWindow()